<section class="ls section_padding_bottom_25">
				<div class="container">
                <div class="row">
						<div class="col-sm-12">
							<h3 class="module-header">Top Most Branches</h3>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div id="gallery-owl-carousel" class="owl-carousel dots-center with_background_items" data-dots="true" data-items="3" data-responsive-lg="3" data-responsive-md="2" data-responsive-sm="2" data-responsive-xs="1">
								<article class="bg_cr vertical-item content-padding post format-standard with_background rounded overflow-hidden text-center ">

									<div class="item-media">

										<img src="images/map.png" alt="">

									</div>

									<div class="item-content">
										<header class="entry-header">
											<h4 class="entry-title">
												<a href="https://goo.gl/maps/pe1hbaEJFcgeH4pVA" rel="bookmark">
									Gurgaon
								</a>
											</h4>
										</header>
										<p>
                                            GOURAV TRANSLOGISTC PVT LTD
                                            Moveclues Relocation Pvt Ltd,
                                            NEAR MUKESH CARRIER , MARUTI GATE NO 02 , CATER PURI ROAD , OPP. KUMAR FARM HOUSE , MARUTI PARKING GURGOAN -122017
                                        </p>
                                        </div>

								</article>
								<article class="bg_cr vertical-item content-padding post format-standard with_background rounded overflow-hidden text-center">

									<div class="item-media">

										<img src="images/map.png" alt="">

									</div>
									<div class="item-content">
										<header class="entry-header">
											<h4 class="entry-title">
												<a href="https://goo.gl/maps/73JSi5qkSBjMsmac9" rel="bookmark">
                                                Chennai
											</a>
											</h4>
										</header>
										<p>
										GOURAV TRANSLOGISTIC PVT LTD
                                            , Moveclues Relocation Pvt Ltd,
    										CHENNAI,SIPCOT TRUCK PARKING, SIPCOT TRUCK PARKING, NH4, HYUNDAI Motors Plant, Sriperumbudur, Kanchipuram, TN</p>
									</div>

								</article>
								<article class="bg_cr vertical-item content-padding post format-standard with_background rounded overflow-hidden text-center">

									<div class="item-media">

										<img src="images/map.png" alt="">
									</div>

									<div class="item-content">
										<header class="entry-header">
											<h4 class="entry-title">
												<a href="https://goo.gl/maps/hFZfsJWzU2NG76eu7" rel="bookmark">
													Bangalore
												</a>
											</h4>
										</header>
										<p>
										Gourav Trans Logistic Pvt Ltd
										Moveclues Relocation Pvt Ltd,
										Shop No.38/2 URL Compound, Madnayakanhalli Bangalore.562123
										Contact-8880044732
										</p>
									</div>

								</article>
								<article class="bg_cr vertical-item content-padding post format-standard with_background rounded overflow-hidden text-center">

									<div class="item-media">

										<img src="images/map.png" alt="">
									</div>

									<div class="item-content">
										<header class="entry-header">
											<h4 class="entry-title">
												<a href="https://goo.gl/maps/RK3RmeVTDw3EB5cu9" rel="bookmark">
												Hyderabad
											</a>
											</h4>
										</header>
										<p>
										
								M/S Gourav Trans Logistics P LTD,
								Moveclues Relocation Pvt Ltd,
								7/3, DSR Complex, Bank Of Baroda, building Kompally Secundrabad- 500014
								</p>
									</div>

								</article>
								<article class="bg_cr vertical-item content-padding post format-standard with_background rounded overflow-hidden text-center">

									<div class="item-media">

										<img src="images/map.png" alt="">
									</div>

									<div class="item-content">
										<header class="entry-header">
											<h4 class="entry-title">
												<a href="#" rel="bookmark">
										Mumbai
										</a>
										</h4>
										</header>
										<p>
										BOULEVARD-4, Promenade by The, Lal Bahadur Shastri Rd, Godrej & Boyce Industry Estate, Vikhroli West, Mumbai, Maharashtra 400079
										</p>
									</div>

								</article>


							</div>
						</div>


					</div>
				</div>
			</section>
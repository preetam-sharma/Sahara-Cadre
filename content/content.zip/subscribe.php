<section id="subscribe"
				class="section_subscribe cs section_padding_top_65 section_padding_bottom_65 table_section table_section_md columns_padding_0">
				<div class="container">
					<div class="row">
						<div class="col-md-8 text-center text-md-left">
							<h3 class="margin_0">Please track your order
								<span class="grey"> With Refference No.</span>
							</h3>
						</div>
						<div class="col-md-4 text-center text-md-right">
							<div class="widget widget_mailchimp">
								<form class="signup" action="https://html.modernwebtemplates.com/mover/" method="get">
									<div class="form-group margin_0">
										<input class="mailchimp_email form-control" name="email" type="email"
											placeholder="Email Address">
									</div>
									<button type="submit" class="theme_button no_bg_button">Sign Up!</button>
									<div class="response"></div>
								</form>
							</div>
						</div>
					</div>
				</div>
</section>
<section class="intro_section page_mainslider ls ms">
				<div class="flexslider" data-nav="false">
					<ul class="slides">
					    
					    <li>
							<img src="images/slide01.png" alt="">
							<div class="container">
								<div class="row">
									<div class="col-sm-12 text-right">
										<div class="slide_description_wrapper">
											<div class="slide_description text-left">
												<div class="intro-layer" data-animation="fadeInUp">
													<h3>
														Find out why we're
													</h3>
													<h2>
														<span class="highlight">#1</span> Moving CO.
													</h2>
												</div>
												<div class="intro-layer" data-animation="fadeInUp">
													<p class="grey"><span class="bold">Move Clues</span> is a India's
														best company with experts and professionals, who cater to
														customer needs with safety, care and love. Call us now: <span
															class="bold">1800-12-11171</span></p>
												</div>
												<div class="intro-layer" data-animation="fadeInUp">
													<a href="#appointment" class="theme_button color1">Get free quote</a>
												</div>
											</div>
											<!-- eof .slide_description -->
										</div>
										<!-- eof .slide_description_wrapper -->
									</div>
									<!-- eof .col-* -->
								</div>
								<!-- eof .row -->
							</div>
							<!-- eof .container -->
						</li>

					<li>
							<img src="images/slide02.jpg" alt="">
							<div class="container">
								<div class="row">
									<div class="col-sm-12">
										<div class="slide_description_wrapper">
											<div class="slide_description">
												<div class="intro-layer" data-animation="fadeInUp">
													<h3>
														Over
														<span class="highlight">600</span> Reviews
													</h3>
													<h2>
														Five Stars
													</h2>
												</div>
												<div class="intro-layer" data-animation="fadeInUp">
													<p class="grey"><span class="bold">Move Clues</span> is a India's
														best company with experts and professionals, who cater to
														customer needs with safety, care and love. Call us now: <span
															class="bold">1800-12-11171</span></p>
												</div>
												<div class="intro-layer" data-animation="fadeInUp">
													<a href="#appointment" class="theme_button color1">Get free quote</a>
												</div>
											</div>
											<!-- eof .slide_description -->
										</div>
										<!-- eof .slide_description_wrapper -->
									</div>
									<!-- eof .col-* -->
								</div>
								<!-- eof .row -->
							</div>
							<!-- eof .container -->
						</li>

						
						
						<!--<li class="ds">-->
						<!--	<img src="images/slide03.jpg" alt="">-->
						<!--	<div class="container">-->
						<!--		<div class="row">-->
						<!--			<div class="col-sm-12 text-center">-->
						<!--				<div class="slide_description_wrapper">-->
						<!--					<div class="slide_description">-->
						<!--						<div class="intro-layer" data-animation="fadeInUp">-->
						<!--							<h3 class="highlight">-->
						<!--								Commercial &amp; Residential-->
						<!--							</h3>-->
						<!--							<h3>-->
						<!--								Relocate Services-->
						<!--							</h3>-->
						<!--						</div>-->
						<!--						<div class="intro-layer" data-animation="fadeInUp">-->
						<!--							<p class="grey"><span class="bold">Move Clues</span> is a India's-->
						<!--								best company with experts and professionals, who cater to-->
						<!--								customer needs with safety, care and love. Call us now: <span-->
						<!--									class="bold">1800-12-11171 </span></p>-->
						<!--						</div>-->
						<!--						<div class="intro-layer" data-animation="fadeInUp">-->
						<!--							<a href="#appointment" class="theme_button color1">Get free quote</a>-->
						<!--						</div>-->
						<!--					</div>-->
						<!--				</div>-->
						<!--			</div>-->
						<!--		</div>-->
						<!--	</div>-->
						<!--</li>-->

					</ul>
				</div>
			</section>
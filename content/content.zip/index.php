<?php include 'header.php';?>
<!-- <?php include 'enq.php';?> -->
<?php include 'banner.php';?>
<?php include 'services.php';?>
<?php include 'about_content.php';?>
<?php include 'appointment.php';?>
<?php include 'mission.php';?>
<!-- <?php include 'faq.php';?> -->
<?php include 'testinomial.php';?>
<?php include 'subscribe.php';?>
<?php include 'footer.php';?>